import React, { useState, useEffect } from "react";
import axios from "axios";

const MasterFrameList = () => {
  const { m_frames, setMasterFrame } = useState([]);

  //   useEffect(() => {
  //     getMasterFrames();
  //   }, []);

  //   const getMasterFrames = async () => {
  //     const response = await axios.get("http://localhost:5003/getMframe");
  //     console.log(response.data);
  //     setMasterFrame(response.data);
  //   };

  useEffect(() => {
    const getMasterFrames = async () => {
      const response = await axios.get("http://localhost:5003/getMframe");
      console.log(response.data);
      setMasterFrame(response.data);
    };
    getMasterFrames();
  }, []);

  return (
    <div className="columns mt-5 is-centered">
      <div className="column is-half">
        <h1>Lorem ipsum dolor sit amet. HEEELLPPP</h1>
        <table className="table is-striped is-fullwidth">
          <thead>
            <tr>
              <th>No</th>
              <th>Kode Site</th>
              <th>Serial Frame</th>
              <th>Ip</th>
              <th>CreatedAt</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {m_frames.map((m_frame, index) => (
              <tr key={m_frame.id}>
                <td>{index + 1}</td>
                <td>{m_frame.kd_site}</td>
                <td>{m_frame.sn_frme}</td>
                <td>{m_frame.ip_adrs}</td>
                <td>{m_frame.createdAt}</td>
                <td>
                  <button className="button is-small is-info">Edit</button>
                </td>
                <td>
                  <button className="button is-small is-danger">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MasterFrameList;
