import React from "react";

const UserList = () => {
  return (
    <div className="columns mt-5 is-centered">
      <div className="column is-half">
        <h1>Lorem ipsum dolor sit amet. HEEELLPPP</h1>
        <table className="table is-striped is-fullwidth">
          <thead>
            <tr>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserList;
