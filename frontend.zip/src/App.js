import MasterFrame from "./components/MasterFrame";
function App() {
  return (
    <div>
      <MasterFrame />
    </div>
  );
}

export default App;
